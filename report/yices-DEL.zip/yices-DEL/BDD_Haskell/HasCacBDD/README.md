HasCacBDD
=========

Haskell bindings for CacBDD, a BDD Package with Dynamic Cache Management.

Using CacBDD from http://kailesu.net/CacBDD/

You probably want to type 'make all' which will:

1. Download CacBDD from http://www.kailesu.net/CacBDD/CacBDD1.01.zip
2. Install a C-wrapped version of CacBDD to /usr/local/cacbdd/
3. Install Data.HasCacBDD  with cabal.

For more details look at the Makefile.
