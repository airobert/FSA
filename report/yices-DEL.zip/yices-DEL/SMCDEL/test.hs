module Test where
  import Math.SMT.Yices.Parser
  import Math.SMT.Yices.Syntax
  import Math.SMT.Yices.Pipe
  import Data.List
  import Control.Monad
  import DELLANG


  int = VarT "int"
  nat = VarT "nat"
  bool = VarT "bool"
  real = VarT "real"

  true = LitB True
  false = LitB False

  yicesPath = "/Users/robertwhite/Projects/yices-1.0.40/bin/yices" -- your yices path

  test_1 = 
    let p1 = PrpF (P 1) in 
    let p2 = PrpF (P 2) in 
    let p = Conj [p1, p2] in 
    let q = Impl p p2 in 
    q

  test_1' = 
    let p1 = PrpF (P 1) in 
    let p2 = PrpF (P 2) in 
    Conj [p1, p2]

  translateY :: Form -> ExpY
  translateY (Top) = true
  translateY (Bot) = false
  translateY (PrpF (P x)) = 
    VarE (show x)
  translateY (Neg l) = 
    NOT (translateY l)
  translateY (Conj l) = 
    AND (map translateY l)
  translateY (Disj l) =
    OR (map translateY l)
  translateY (Xor []) = false 
  translateY (Xor l) =
    let (b:bs) = map translateY l in 
    foldl myxor b bs
    where 
      myxor :: ExpY -> ExpY -> ExpY
      myxor s t  = (AND[OR[s, t], NOT (AND [s, t])])
    -- I am not very sure about this
  translateY (Impl p1 p2) = 
    (translateY p1) :=> (translateY p2)
  translateY (Equi p1 p2) = 
    (translateY p1) :=  (translateY p2)


  translateY (Forall l f) = 
    let l' = map (\(P x) -> (show x, bool)) l in 
    FORALL l' (translateY f)
  translateY (Exists l f) = 
    let l' = map (\(P x) -> (show x, bool)) l in 
    EXISTS l' (translateY f)
  translateY _ = true


  test_2 = 
    print (translateY test_1)

  eval :: Form -> IO Bool
  eval ex = do
    let def = defs (propsInForm ex)
    print def
    let ass = ASSERT (boolSMTOf ex)
    print ass
    yp@(Just hin, Just hout, Nothing, p) <- createYicesPipe yicesPath [] 
    runCmdsY yp (def ++ [ass]) 
    check <- checkY yp
    return $
      case check of 
        Sat ss -> True
        UnSat _ -> False
        Unknown _ -> error "SMT gives an unknown as reply"
        otherwise -> error "SMT gives other replies"


  eval' :: ExpY -> IO Bool
  eval' ex = do
    let def = (propsInExp ex)
    print def
    let ass = ASSERT (ex)
    print ass
    yp@(Just hin, Just hout, Nothing, p) <- createYicesPipe yicesPath [] 
    runCmdsY yp (def ++ [ass]) 
    check <- checkY yp
    return $
      case check of 
        Sat ss -> True
        UnSat _ -> False
        Unknown _ -> error "SMT gives an unknown as reply"
        otherwise -> error "SMT gives other replies"


  test_3 = eval test_1


  defs :: [Prp] -> [CmdY]
  defs sl = 
    map (\(P i) -> DEFINE ((name i), bool) Nothing) sl

  name :: Int -> String
  name x = "p_" ++ (show x)

  boolSMTOf :: Form -> ExpY
  boolSMTOf Top           = true
  boolSMTOf Bot           = false
  boolSMTOf p@(PrpF (P n))  = VarE (name n)
  boolSMTOf (Neg forms)    = NOT (boolSMTOf forms)
  boolSMTOf (Conj forms)  = AND (map boolSMTOf forms)
  boolSMTOf (Disj forms)  = OR (map boolSMTOf forms)
  boolSMTOf (Xor [])      = false 
  boolSMTOf (Xor l)       = 
    let (b:bs) = map boolSMTOf l in 
    foldl myxor b bs
    where 
      myxor :: ExpY -> ExpY -> ExpY
      myxor s t  = (AND[OR[s, t], NOT (AND [s, t])])
 --  can we translate this as not equal ?
  boolSMTOf (Impl p1 p2)    = (boolSMTOf p1) :=> (boolSMTOf p2)
  boolSMTOf (Equi p1 p2)    = (boolSMTOf p1) :=  (boolSMTOf p2)
  boolSMTOf (Forall ps f) = 
    let ps' = map (\(P x) -> (show x, bool)) ps in 
    FORALL ps' (boolSMTOf f)
  boolSMTOf (Exists ps f) = 
    let ps' = map (\(P x) -> (show x, bool)) ps in 
    FORALL ps' (boolSMTOf f)
  boolSMTOf _             = error "boolSMTOf failed: Not a boolean formula."

-- | Greatest fixpoint for a given operator.
gfp :: (ExpY -> ExpY) -> IO ExpY
gfp operator = gfpStep true (operator true) where
  gfpStep :: ExpY -> ExpY -> IO ExpY
  gfpStep current next =
    let def = nubBy define_eq $ (propsInExp current) ++ (propsInExp next)
    if eval' (current := next)
      then (return current)
      else (return (gfpStep next (operator next)))


  propsInExp :: ExpY -> [CmdY]
  propsInExp (VarE n)           = [(DEFINE (n, bool) Nothing)]
  propsInExp (NOT f)            = propsInExp f
  propsInExp (AND fs)          = nubBy define_eq $ concatMap propsInExp fs
  propsInExp (OR fs)          = nubBy define_eq $ concatMap propsInExp fs
  --propsInExp (Xor  fs)          = nubBy define_eq $ concatMap propsInExp fs
  propsInExp (f :=> g)         = nubBy define_eq $ concatMap propsInExp [f,g]
  propsInExp (f := g)         = nubBy define_eq $ concatMap propsInExp [f,g]
  propsInExp (FORALL ps f)      = nubBy define_eq $ (map (\x -> DEFINE x Nothing) ps) ++ propsInExp f
  propsInExp (EXISTS ps f)      = nubBy define_eq $ (map (\x -> DEFINE x Nothing) ps) ++ propsInExp f
  propsInExp true                = []
  propsInExp false               = []
  propsInExp _ = error "no match"
  --remember to concat 
  define_eq x y = 
    let (DEFINE (s, bool) Nothing)  = x in 
    let (DEFINE (t, bool) Nothing)  = y in 
    (s == t)

  test_4 = propsInExp (boolSMTOf test_1)
  test_4' = propsInExp (boolSMTOf (PrpF (P 1)))


--    data Form =
--    Top | Bot | PrpF Prp | Neg Form | Conj [Form] | Disj [Form] | Xor [Form] |
--    Impl Form Form | Equi Form Form | Forall [Prp] Form | Exists [Prp] Form |
--    K Agent Form | Ck [Agent] Form | Kw Agent Form | Ckw [Agent] Form |
--    PubAnnounce Form Form | PubAnnounceW Form Form |
--    Announce [Agent] Form Form | AnnounceW [Agent] Form Form
--    deriving (Eq,Ord,Show)

---- | yices expressions
--data ExpY
--  = VarE String
--  | LitB Bool
--  | LitI Integer
--  | LitR Rational
--  | AND [ExpY]
--  | OR [ExpY]
--  | NOT ExpY
--  | ExpY :=> ExpY
--  | ExpY := ExpY
--  | ExpY :/= ExpY
--  | ExpY :< ExpY
--  | ExpY :<= ExpY
--  | ExpY :> ExpY
--  | ExpY :>= ExpY
--  | ExpY :+: ExpY
--  | ExpY :-: ExpY
--  | ExpY :*: ExpY
--  | ExpY :/: ExpY
--  | DIV ExpY ExpY
--  | MOD ExpY ExpY
--  | IF ExpY ExpY ExpY
--  | ITE ExpY ExpY ExpY
--  | LET [((String,Maybe TypY),ExpY)] ExpY
--  -- quantifires
--  | FORALL [(String,TypY)] ExpY
--  | EXISTS [(String,TypY)] ExpY
--  -- functions
--  | APP ExpY [ExpY]
--  | UPDATE_F ExpY [ExpY] ExpY
--  | LAMBDA [(String,TypY)] ExpY
--  -- tuples
--  | MKTUP [ExpY]
--  | SELECT_T ExpY Integer
--  | UPDATE_T ExpY Integer ExpY
--  -- records
--  | MKREC [(String,ExpY)]
--  | SELECT_R ExpY String
--  | UPDATE_R ExpY String ExpY
--  -- bitvectors -- TODO